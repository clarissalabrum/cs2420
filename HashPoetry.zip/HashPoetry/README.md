•	**What knowledge do human beings have that is NOT captured by this language model and that therefore causes the model to generate nonsense. Write down at least three facts that, if the computer could somehow know them, would allow it to generate more sensible language.**

The part that a computer is missing in writing a 
poem is the structure of the language and the meaning
of the words.

1. If the computer could know if one word following
another word has meaning or not it could pick a 
more meaningful word.

2. If a computer could know that a language
has a structure to it; nouns, verbs, adjectives,
it could better place words in a correct order.

3. I computer would need to have a bit of creativity
to write a poem, it would be better to place this 
word instead of that because it makes the poem 
more creative.

•	**Compare the different poems. If your experience is like mine, some will be more coherent than others. Speculate about why this is true.**

In some poems a unique word is picked. By unique I 
mean that it only occurs once. If you have a 
string of unique words the will be no variation 
caused the the computer and segments of the new poem
matches the actual poem.